import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class RunRecord {
  final String id;
  final DateTime date;
  final double distanceMeters;
  final int movingSeconds;
  final int elapsedSeconds;
  final double elevationGain;
  final double maxElevation;
  final double maxSpeed;
  final double calories;
  final List<List<double>> route; // [latitude, longitude]

  const RunRecord({required this.id, required this.date, required this.distanceMeters,
    required this.movingSeconds, required this.elapsedSeconds, required this.elevationGain,
    required this.maxElevation, required this.maxSpeed, required this.calories, required this.route});

  double get averageSpeed => movingSeconds > 0 ? (distanceMeters / 1000) / (movingSeconds / 3600) : 0;
  String get pace {
    if (distanceMeters < 1 || movingSeconds < 1) return '--:--';
    final seconds = (movingSeconds / (distanceMeters / 1000)).round();
    return '${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';
  }

  Map<String, dynamic> toJson() => {
    'id': id, 'date': date.toIso8601String(), 'distanceMeters': distanceMeters,
    'movingSeconds': movingSeconds, 'elapsedSeconds': elapsedSeconds,
    'elevationGain': elevationGain, 'maxElevation': maxElevation,
    'maxSpeed': maxSpeed, 'calories': calories, 'route': route,
  };

  factory RunRecord.fromJson(Map<String, dynamic> json) => RunRecord(
    id: json['id'] as String,
    date: DateTime.parse(json['date'] as String),
    distanceMeters: (json['distanceMeters'] as num).toDouble(),
    movingSeconds: json['movingSeconds'] as int,
    elapsedSeconds: json['elapsedSeconds'] as int,
    elevationGain: (json['elevationGain'] as num).toDouble(),
    maxElevation: (json['maxElevation'] as num).toDouble(),
    maxSpeed: (json['maxSpeed'] as num).toDouble(),
    calories: (json['calories'] as num).toDouble(),
    route: (json['route'] as List<dynamic>).map((p) => (p as List<dynamic>).map((v) => (v as num).toDouble()).toList()).toList(),
  );
}

class RunHistoryService {
  static const _key = 'runova_saved_runs_v1';

  static Future<List<RunRecord>> getRuns() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      final runs = list.map((item) => RunRecord.fromJson(Map<String, dynamic>.from(item as Map))).toList();
      runs.sort((a, b) => b.date.compareTo(a.date));
      return runs;
    } catch (_) {
      return [];
    }
  }

  static Future<void> saveRun(RunRecord run) async {
    final runs = await getRuns();
    runs.removeWhere((item) => item.id == run.id);
    runs.insert(0, run);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(runs.map((item) => item.toJson()).toList()));
  }

  static Future<void> deleteRun(String id) async {
    final runs = await getRuns();
    runs.removeWhere((item) => item.id == id);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(runs.map((item) => item.toJson()).toList()));
  }
}
