import 'package:shared_preferences/shared_preferences.dart';

/// Demo-only local sign-in. Replace with Firebase Auth before publishing.
class AuthService {
  static const _signedInKey = 'runova_signed_in';
  static const _emailKey = 'runova_email';
  static bool isSignedIn = false;
  static String email = '';

  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    isSignedIn = prefs.getBool(_signedInKey) ?? false;
    email = prefs.getString(_emailKey) ?? '';
  }

  static Future<void> signIn(String value, String password) async {
    _validate(value, password);
    final prefs = await SharedPreferences.getInstance();
    email = value.trim();
    isSignedIn = true;
    await prefs.setBool(_signedInKey, true);
    await prefs.setString(_emailKey, email);
  }

  static Future<void> signUp(String value, String password) async {
    _validate(value, password);
    await signIn(value, password);
  }

  static void _validate(String value, String password) {
    if (!value.contains('@') || !value.contains('.')) throw Exception('Enter a valid email address.');
    if (password.length < 6) throw Exception('Password must be at least 6 characters.');
  }

  static Future<void> signOut() async {
    final prefs = await SharedPreferences.getInstance();
    isSignedIn = false;
    email = '';
    await prefs.setBool(_signedInKey, false);
    await prefs.remove(_emailKey);
  }
}
