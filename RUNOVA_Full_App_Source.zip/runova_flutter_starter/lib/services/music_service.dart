import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class MusicService {
  static Future<void> openMusic(BuildContext context) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const ListTile(title: Text('Open a music app')),
        ListTile(leading: const Icon(Icons.music_note), title: const Text('Spotify'), onTap: () => Navigator.pop(context, 'https://open.spotify.com/')),
        ListTile(leading: const Icon(Icons.play_circle_outline), title: const Text('YouTube Music'), onTap: () => Navigator.pop(context, 'https://music.youtube.com/')),
        ListTile(leading: const Icon(Icons.apple), title: const Text('Apple Music'), onTap: () => Navigator.pop(context, 'https://music.apple.com/')),
      ])),
    );
    if (choice == null) return;
    final uri = Uri.parse(choice);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open the selected music app.')));
    }
  }
}
