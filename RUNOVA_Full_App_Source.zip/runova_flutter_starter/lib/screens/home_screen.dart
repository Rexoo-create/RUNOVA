import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import 'auth_screen.dart';
import 'run_screen.dart';
import 'coach_screen.dart';
import 'history_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatefulWidget {
  final VoidCallback onThemeToggle;
  const HomeScreen({super.key, required this.onThemeToggle});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;

  Future<void> _logout() async {
    await AuthService.signOut();
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => AuthScreen(onThemeToggle: widget.onThemeToggle)), (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _dashboard(context),
      const RunScreen(),
      const CoachScreen(),
      const HistoryScreen(),
      const ProfileScreen(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('RUNOVA', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 3)),
        actions: [
          IconButton(tooltip: 'Change theme', onPressed: widget.onThemeToggle, icon: const Icon(Icons.brightness_6_outlined)),
          IconButton(tooltip: 'Sign out', onPressed: _logout, icon: const Icon(Icons.logout_rounded)),
        ],
      ),
      body: IndexedStack(index: tab, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.directions_run), label: 'Run'),
          NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'AI Coach'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _dashboard(BuildContext context) {
    final lime = const Color(0xFFB8F34A);
    return ListView(padding: const EdgeInsets.all(20), children: [
      Text('Your next run starts here.', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text('Track your distance, pace and elevation.', style: TextStyle(color: Theme.of(context).hintColor)),
      const SizedBox(height: 22),
      Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: const LinearGradient(colors: [Color(0xFFB8F34A), Color(0xFF79B92E)], begin: Alignment.topLeft, end: Alignment.bottomRight),
          boxShadow: [BoxShadow(color: lime.withOpacity(.22), blurRadius: 25, offset: const Offset(0, 12))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('READY TO MOVE?', style: TextStyle(color: Colors.black54, letterSpacing: 2, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          const Text('Every kilometre counts.', style: TextStyle(color: Colors.black, fontSize: 25, fontWeight: FontWeight.w900)),
          const SizedBox(height: 18),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: Colors.black, foregroundColor: Colors.white),
            onPressed: () => setState(() => tab = 1),
            icon: const Icon(Icons.play_arrow), label: const Text('START RUN'),
          ),
        ]),
      ),
      const SizedBox(height: 24),
      Text('YOUR RUNNING TOOLS', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold, letterSpacing: 1)),
      const SizedBox(height: 12),
      _quickTile(context, Icons.map_outlined, 'Live GPS Tracking', 'Distance, pace, speed and route', () => setState(() => tab = 1)),
      _quickTile(context, Icons.auto_awesome, 'AI Running Coach', 'Create a simple training plan', () => setState(() => tab = 2)),
      _quickTile(context, Icons.history, 'Running History', 'Review your saved activities', () => setState(() => tab = 3)),
      const SizedBox(height: 12),
      Text('GPS needs location permission. Keep the app open during a run; background tracking is not included in this starter version.', style: TextStyle(color: Theme.of(context).hintColor, fontSize: 12)),
    ]);
  }

  Widget _quickTile(BuildContext context, IconData icon, String title, String subtitle, VoidCallback onTap) => Card(
    child: ListTile(leading: Icon(icon, color: const Color(0xFF9BCB3B)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right), onTap: onTap),
  );
}
