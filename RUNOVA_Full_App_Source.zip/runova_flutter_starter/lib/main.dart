import 'package:flutter/material.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'services/auth_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AuthService.init();
  runApp(const RunovaApp());
}

class RunovaApp extends StatefulWidget {
  const RunovaApp({super.key});
  @override
  State<RunovaApp> createState() => _RunovaAppState();
}

class _RunovaAppState extends State<RunovaApp> {
  ThemeMode mode = ThemeMode.dark;
  void toggleTheme() => setState(() => mode = mode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark);

  @override
  Widget build(BuildContext context) {
    const lime = Color(0xFFB8F34A);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'RUNOVA',
      themeMode: mode,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSeed(seedColor: lime, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF3F6F0),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: lime, brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF101510),
      ),
      home: AuthService.isSignedIn
          ? HomeScreen(onThemeToggle: toggleTheme)
          : AuthScreen(onThemeToggle: toggleTheme),
    );
  }
}
