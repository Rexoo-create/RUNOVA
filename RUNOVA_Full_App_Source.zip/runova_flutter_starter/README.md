# RUNOVA — Flutter starter app

RUNOVA is a running-tracker starter project with a lime/charcoal visual identity.

## Included screens and features

- Splash/start flow through sign-in or account creation
- Local demo sign-in (not production authentication)
- Home dashboard and five-tab navigation
- Dark and light theme toggle
- Live GPS run screen with OpenStreetMap route, distance, moving time, elapsed time, average pace, current/max speed, elevation gain and max elevation
- Pause, resume and finish controls
- Local running history saved with SharedPreferences
- History filters: all time, this week, this month
- Run details with route map and metrics; delete saved runs
- Sample goal-based running coach (not a live AI service)
- External launch links for Spotify, YouTube Music and Apple Music
- Profile screen
- Heart-rate feature intentionally excluded

## Requirements

- Flutter 3.22+ recommended
- Android Studio / Android SDK or Xcode for iOS builds
- Internet connection for OpenStreetMap tiles

## Run the app

```bash
flutter pub get
flutter run
```

For Android, location and internet permissions are declared in `android/app/src/main/AndroidManifest.xml`.
For iOS, add the following keys to `ios/Runner/Info.plist` inside the main `<dict>`:

```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>RUNOVA uses your location to record your running route and distance.</string>
```

## Important limitations before publishing

1. **Authentication:** The included sign-in is a local demo gate. It does not securely verify accounts or store passwords. Replace `lib/services/auth_service.dart` with Firebase Authentication or another trusted authentication provider before release.
2. **History:** Activities are saved on this device using SharedPreferences. There is no cloud backup or account sync.
3. **Background tracking:** This starter tracks while the app is open. It does not implement a background location service. Keep RUNOVA open during a run.
4. **AI Coach:** The coach creates a sample plan using local rules; it is not connected to an AI model and does not analyze actual training history.
5. **Music:** Music buttons open the selected music service. They do not control playback inside RUNOVA.
6. **GPS accuracy:** Distance, speed and elevation are estimates and can be affected by device GPS quality, buildings, weather and map data. Do not use the app as a safety or medical device.
7. **Calories:** Calories are a rough estimate, not a measured value.
8. **Voice updates and auto-pause:** Not included in this starter build.

## Project structure

```text
lib/
  main.dart
  screens/
    auth_screen.dart
    home_screen.dart
    run_screen.dart
    coach_screen.dart
    history_screen.dart
    profile_screen.dart
  services/
    auth_service.dart
    music_service.dart
    run_history_service.dart
```

## Build APK

```bash
flutter build apk --release
```

The generated APK is normally at `build/app/outputs/flutter-apk/app-release.apk`.
